# Sidebar Menu Hover Show/Hide CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/JFarrow/pen/nJgRga](https://codepen.io/JFarrow/pen/nJgRga).

Sidebar Menu Hover Show/Hide with just CSS